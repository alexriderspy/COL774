import numpy as np

from sklearn.svm import SVC
import numpy as np
import sys,os,pickle
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt

sys.path.append('../Qa')
import qa

train_path = str(sys.argv[1])
test_path = str(sys.argv[2])

file = os.path.join(train_path,'train_data.pickle')
test_file = os.path.join(test_path,'test_data.pickle')

with open(file, 'rb') as fo:
    dict = pickle.load(fo, encoding='bytes')

labels = dict['labels']
data = dict['data']

arrY = []
arrX = []

#3 -> -1, 4 -> 1

for i in range(len(labels)):
    arrX.append(data[i].flatten())
    arrY.append(labels[i])

m = len(arrX)
arrX = np.array(arrX).reshape(m,3072)
arrY = np.ravel(arrY)

arrX = np.multiply(arrX,1.0)

arrX/=255.0

with open(test_file, 'rb') as fo:
    test_dict = pickle.load(fo, encoding='bytes')

test_labels = test_dict['labels']
test_data = test_dict['data']

test_arrY = []
test_arrX = []

#3 -> -1, 4 -> 1

for i in range(len(test_labels)):
    test_arrX.append(test_data[i].flatten())
    test_arrY.append(test_labels[i])

test_m = len(test_arrX)
test_arrX = np.array(test_arrX).reshape(test_m,3072)
test_arrY = np.ravel(test_arrY)

test_arrX = np.multiply(test_arrX,1.0)

test_arrX/=255.0

model = SVC(kernel = 'rbf',gamma = 0.001,decision_function_shape='ovo')
model.fit(arrX, arrY)
yhat = model.predict(test_arrX)

cm = confusion_matrix(test_arrY,yhat)

print("confusion matrix for sklearn model: ")
print(cm)

cm = confusion_matrix(test_arrY,qa.yhat)

print("confusion matrix for cvxopt model : ")
print(cm)

arr_mis = qa.arr_mis_classified

for i in range(len(arr_mis)):
    img = arr_mis[i]
    img*=255.0
    img = img.reshape((32,32,3)).astype('uint8')
    plt.imsave('Image_miss_' + str(i)+ '.png',img)
